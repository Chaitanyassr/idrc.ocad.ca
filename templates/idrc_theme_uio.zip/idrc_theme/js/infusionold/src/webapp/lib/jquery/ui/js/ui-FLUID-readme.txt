The jquery.ui.*.js files in this folder were taken from the 1.8.18 bundle, downloaded April 4th, 2012
http://jquery-ui.googlecode.com/files/jquery-ui-1.8.18.zip
